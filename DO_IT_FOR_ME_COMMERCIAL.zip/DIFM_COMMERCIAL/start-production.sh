#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -f .env ]]; then
  echo "Copy .env.example to .env and configure secrets first."
  exit 1
fi
export NODE_ENV=production
exec node server.js
